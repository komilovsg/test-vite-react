import { createContext } from "react";

// ШАГ 5. Второй контекст — язык интерфейса.
// Контекстов в приложении может быть сколько угодно,
// каждый отвечает за свою часть данных.
export const LanguageContext = createContext();

// Словарь переводов. Ключ верхнего уровня — код языка,
// внутри — все тексты интерфейса.
// Компоненты берут текст так: translations[lang].counter
export const translations = {
  ru: {
    appTitle: "Учебный проект",
    themeToLight: "Светлая тема",
    themeToDark: "Тёмная тема",
    counter: "Счётчик",
    reset: "Сброс",
    refTitle: "useRef: автофокус и «коробка»",
    inputPlaceholder: "Автофокус при загрузке",
    clicksInBox: "Кликов в «коробке» (без ререндера)",
    showBox: "Показать значение из ref",
    footer: "Один проект — шесть шагов",
  },
  en: {
    appTitle: "Study project",
    themeToLight: "Light theme",
    themeToDark: "Dark theme",
    counter: "Counter",
    reset: "Reset",
    refTitle: "useRef: autofocus and the “box”",
    inputPlaceholder: "Autofocus on load",
    clicksInBox: "Clicks in the “box” (no re-render)",
    showBox: "Show value from ref",
    footer: "One project — six steps",
  },
};
