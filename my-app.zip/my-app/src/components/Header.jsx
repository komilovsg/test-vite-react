import { useContext } from "react";
import { ThemeContext } from "../store/ThemeContext";
import { LanguageContext, translations } from "../store/LanguageContext";

// ШАГ 3 + ШАГ 4. Header — «шапка» приложения.
// Здесь живут кнопки смены темы и языка.
export default function Header() {
  // useContext достаёт значение из ближайшего Provider выше по дереву.
  // Никаких пропсов — Header сам «подписывается» на нужные данные.
  const { theme, setTheme } = useContext(ThemeContext);
  const { lang, setLang } = useContext(LanguageContext);

  // t — все тексты для текущего языка (см. словарь в LanguageContext.jsx)
  const t = translations[lang];

  return (
    <header className="header">
      <h1 className="header__title">{t.appTitle}</h1>

      <div className="header__actions">
        {/* Кнопка темы: меняем state в App через setTheme из контекста.
            App перерисуется, useEffect повесит класс на <body> —
            и тема меняется у ВСЕЙ страницы */}
        <button
          className="btn"
          onClick={() => setTheme(theme === "light" ? "dark" : "light")}
        >
          {theme === "light" ? t.themeToDark : t.themeToLight}
        </button>

        {/* Кнопка языка: тот же приём, но со вторым контекстом */}
        <button
          className="btn"
          onClick={() => setLang(lang === "ru" ? "en" : "ru")}
        >
          {lang === "ru" ? "EN" : "RU"}
        </button>
      </div>
    </header>
  );
}
