import { useContext } from "react";
import { LanguageContext, translations } from "../store/LanguageContext";

// ШАГ 3. Footer — «подвал» приложения.
// Простой компонент без своего state: только читает язык из контекста.
export default function Footer() {
  const { lang } = useContext(LanguageContext);
  const t = translations[lang];

  return (
    <footer className="footer">
      <p>{t.footer} · 2026</p>
    </footer>
  );
}
